<?php
    $notices = App\Models\Notice::get();
?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>نافذة الحق</title>
    <link rel="icon" href="/img/icon.ico">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
</head>
<body>


<div class="admin-signup-section">
    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-section_head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-section_head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin_navbar','data' => ['count' => count($waitingEmploye)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin_navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($waitingEmploye))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="adminCreationForm">
        <div class="adminCreationFormOne">
            <img src="/img/frame.svg" alt="">
        </div>


        <div class="adminCreationFormTwo">
            <h1>إظافة موظف جديد</h1>
            <div class="testFormOne">
                <?php if($errors->any()): ?>
                    <div class="theErrorsSection">تعبئة أو اختيار كل حقول الإدخال باللون الأحمر</div>
                <?php endif; ?>
            </div>
        <form action=<?php echo e(route('new-amploye-sub')); ?> method="POST">
            <?php echo csrf_field(); ?>
            <div class="inputLabel">
                <input type="text" id="a" class="input-field <?php if($errors->has('admin_name')): ?> errorInput <?php endif; ?>" name="admin_name" onchange="handleCheck('a', 'z')" value="<?php echo e(old('admin_name')); ?>">
                <label for="" class="input-label" id="z"><span>*  </span>الإسم الكامل</label>
            </div>
            <div class="inputLabel">
                <input type="number" id="e" class="input-field <?php if($errors->has('admin_rental')): ?> errorInput <?php endif; ?>" name="admin_rental" onchange="handleCheck('e', 'r')" value="<?php echo e(old('admin_rental')); ?>">
                <label for="" class="input-label" id="r"><span>*  </span>رقم التأجير</label>
            </div>
            <div class="inputLabel">
                <input type="text" id="t" class="input-field <?php if($errors->has('admin_cadre')): ?> errorInput <?php endif; ?>" name="admin_cadre" onchange="handleCheck('t', 'y')" value="<?php echo e(old('admin_cadre')); ?>">
                <label for="" class="input-label" id="y"><span>*  </span>الإطار</label>
            </div>

            <div class="inputLabel">
                <input type="text" id="c" class="input-field <?php if($errors->has('admin_address')): ?> errorInput <?php endif; ?>" name="admin_address" onchange="handleCheck('c', 'v')" value="<?php echo e(old('admin_address')); ?>">
                <label for="" class="input-label" id="v"><span>*  </span>العنوان الشخصي</label>
            </div>
            <div class="inputLabel">
                <input type="email" id="b" class="input-field <?php if($errors->has('email')): ?> errorInput <?php endif; ?>" name="email" onchange="handleCheck('b', 'n')" value="<?php echo e(old('email')); ?>">
                <label for="" class="input-label" id="n"><span>*  </span>البريد الإلكتروني</label>
            </div>
            <div class="inputLabel">
                <input type="password" id="w" class="input-field <?php if($errors->has('admin_password')): ?> errorInput <?php endif; ?>" name="admin_password" onchange="handleCheck('w', 'x')" value="<?php echo e(old('admin_password')); ?>">
                <label for="" class="input-label" id="x"><span>*  </span>كلمة السر</label>
            </div>
            <div class="inputLabel">
                <input type="password" id="d" class="input-field <?php if($errors->has('admin_password_confirmation')): ?> errorInput <?php endif; ?>" name="admin_password_confirmation" onchange="handleCheck('d', 'f')" value="<?php echo e(old('admin_password_confirmation')); ?>">
                <label for="" class="input-label" id="f"><span>*  </span>تأكيد كلمة السر</label>
            </div>
            <div>
                <button type="submit">إنشاء</button>
            </div>
        </form>
        </div>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.foo_ter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('foo_ter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <script src="/js/main.js"></script>



    
<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.title = 'نافذة الحق' + ' - ' + 'إظافة موظف';
    });
  </script>
</body>
</html>








<?php /**PATH C:\chatApp\chatTest\resources\views/new-employe.blade.php ENDPATH**/ ?>