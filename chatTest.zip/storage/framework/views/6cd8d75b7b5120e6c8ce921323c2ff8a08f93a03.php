<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>نافذة الحق</title>
    <link rel="icon" href="/img/icon.ico">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
</head>
<body>

    <?php if(session()->has('add')): ?>
  <script>
      Swal.fire({
          position: "center-center",
          icon: "success",
          title: "<?php echo e(session('add')); ?>",
          showConfirmButton: false,
          timer: 2000
      });
  </script>
<?php endif; ?>

<?php if(session()->has('validateSucess')): ?>
<script>
    Swal.fire({
        position: "center-center",
        icon: "success",
        title: "<?php echo e(session('validateSucess')); ?>",
        showConfirmButton: false,
        timer: 2000
    });
</script>
<?php endif; ?>


<?php if(session()->has('resetSuccess')): ?>
<script>
    Swal.fire({
        position: "center-center",
        icon: "success",
        title: "<?php echo e(session('resetSuccess')); ?>",
        showConfirmButton: false,
        timer: 2000
    });
</script>
<?php endif; ?>

    <?php if(session()->has('login')): ?>
  <script>
      Swal.fire({
          position: "center-center",
          icon: "error",
          title: "<?php echo e(session('login')); ?>",
          showConfirmButton: false,
          timer: 2000
      });
  </script>
<?php endif; ?>

<div class="user-login-section">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-section_head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-section_head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="userLoginForm">
        <div class="userLoginFormOne">
            <img src="/img/frame.svg" alt="">
        </div>
        <div class="userLoginFormTwo">
            <h1>تسجيل الدخول</h1>
            <div class="theErrorsSectionAlla">
                <?php if($errors->any()): ?>
                    <div class="theErrorsSection">تعبئة أو اختيار كل حقول الإدخال باللون الأحمر</div>
                <?php endif; ?>
                </div>
        <form action=<?php echo e(route('admin.login')); ?> method="POST">
            <?php echo csrf_field(); ?>
            <div class="inputLabel">
                <input type="text" id="w" class="input-field <?php if($errors->has('email')): ?> errorInput <?php endif; ?>" name="email" onchange="handleCheck('w', 'x')" value="<?php echo e(old('email')); ?>">
                <label for="" class="input-label" id="x"><span>*  </span>البريد الإلكتروني</label>
            </div>
            <div class="inputLabel">
                <input type="password" id="c" class="input-field <?php if($errors->has('password')): ?> errorInput <?php endif; ?>" name="password" onchange="handleCheck('c', 'v')" value="<?php echo e(old('password')); ?>">
                <label for="" class="input-label" id="v"><span>*  </span>كلمة السر</label>
            </div>
            <div class="div-login-link">
                <a href="<?php echo e(route('reset.get')); ?>" class="login-link">نسيت كلمة المرور؟</a>
                <a href="<?php echo e(route('signupBladeEmploye')); ?>" class="login-link">ليس لديك حساب؟</a>
            </div>
            <div>
                <button type="submit">تسجيل الدخول</button>
            </div>
        </form>
        </div>
    </div>
</div>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.title = document.title + ' - ' + 'تسجيل-الدخول';
    });
</script>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.foo_ter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('foo_ter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <script src="/js/main.js"></script>
</body>
</html>








<?php /**PATH C:\chatApp\chatTest\resources\views/loginBlade-employe.blade.php ENDPATH**/ ?>