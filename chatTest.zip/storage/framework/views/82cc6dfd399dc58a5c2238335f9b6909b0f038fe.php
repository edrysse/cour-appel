<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <div class="landing-sectionHead">
      
        <div class="head-one"><a href="/"><img src="/img/projet_name.png" alt=""></a></div>
        <div class="head-two"><span style="color: #ffbc2b">مَحكَمة الإسْتئنَاف </span>في خدمة المواطن</div>
        <div class="head-three"><img src="/img/new.png" alt=""></div>
    </div>
</body>
</html><?php /**PATH C:\chatApp\chatTest\resources\views/components/landing-section_head.blade.php ENDPATH**/ ?>