<?php
    $notices = App\Models\Notice::get();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>نافذة الحق</title>
    <link rel="icon" href="/img/icon.ico">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.lordicon.com/lordicon.js"></script>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>
    
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="listMessages-section">

        <?php if(session()->has('delete')): ?>
            <script>
                Swal.fire({
                    position: "center-center",
                    icon: "success",
                    title: "<?php echo e(session('delete')); ?>",
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>
        <?php endif; ?>
        
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-section_head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-section_head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin_navbar','data' => ['count' => count($waitingEmploye)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin_navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($waitingEmploye))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        
          <div class="searchResultWaiting">
            <p>تمكن هذه الواجهة من الإطلاع على جميع الموظفين على مستوى محكمة الإستئناف بالعيون بمختلف الأطر، وكذلك إمكانية حذف الموظفين حسب الرغبة<br><span>.واجهة خاصة بالموظفين تحت مسمى وظيفي رئيس</span></p>



            <div class="searchFieldAdmin">

                <div></div>
                        <div class="searchBtn"><button onclick="search2()">بحث</button></div>
                
                        <div><label for="" class="searchN">نوع عمل الموظف</label></div>
                        <div class="searchName">
                            <input type="text" id="empType" placeholder="نوع عمل الموظف">
                        </div>
                
                        <div>
                            <label for="" class="searchC">رقم تأجير الموظف</label></div>
                        <div class="searchCity">
                            <input type="text" id="empRental" placeholder="رقم تأجير الموظف">
                        </div>
                
                        <div>
                            <label for="" class="searchN">إسم الموظف</label></div>
                        <div class="searchNumber">
                            <input type="text" id="empName" placeholder="إسم الموظف">
                        </div>
                        
                    </div>
          </div>


          <div class="theResult">
            
            <span class="suivie">لائحة الموظفين</span>
          </div>


        <div class="tableDiv">
            <table border="1" class="messages-table">
                <tr>
                    <th>حذف</th>
                    <th>ملاحظات</th>
                    <th>العنوان الشخصي</th>
                    <th>الإطار</th>
                    <th>الإسم الكامل</th>
                    <th>رقم التأجير</th>
                    <th>الرقم الترتيبي</th>
                </tr>
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="messageRow">
                        <td style="text-align: center">
                            <form action="<?php echo e(route('employe.delete', $emp->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="cancelDemande"><i class='bx bx-x'></i></button>
                            </form>
                        </td>
                        <td><?php echo e($emp->observations); ?></td>
                        <td><?php echo e($emp->address); ?></td>
                        <td><?php echo e($emp->cadre); ?></td>
                        <td><?php echo e($emp->admin_name); ?></td>
                        <td><?php echo e($emp->rental_number); ?></td>
                        <td><?php echo e($emp->id - 9); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.foo_ter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('foo_ter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    

    <script>
    
        function search2() {
            var empName = document.getElementById('empName').value.trim().toLowerCase();
            var empRental = document.getElementById('empRental').value.trim().toLowerCase()
            var empType = document.getElementById('empType').value.trim().toLowerCase()
            
            var rows = document.getElementsByClassName('messageRow');
        
            for (var i = 0; i < rows.length; i++) {
                var row = rows[i];
                var empNameCell = row.getElementsByTagName('td')[4];
                var empRentalCell = row.getElementsByTagName('td')[5];
                var empTypeCell = row.getElementsByTagName('td')[3];
                
        
                if (empNameCell.textContent.trim().toLowerCase().includes(empName) && empTypeCell.textContent.trim().toLowerCase().includes(empType) && empRentalCell.textContent.trim().toLowerCase().includes(empRental)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        }
        </script>
        
   
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                document.title = 'نافذة الحق' + ' - ' + 'تدبير الموظفين';
            });
          </script>
</body>
</html>

<?php /**PATH C:\chatApp\chatTest\resources\views/listEmployees.blade.php ENDPATH**/ ?>