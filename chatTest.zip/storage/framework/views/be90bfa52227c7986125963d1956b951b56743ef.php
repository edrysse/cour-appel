<div class="right message">
    <p><?php echo e($message); ?></p>
  </div>
  <?php /**PATH C:\chatApp\chatTest\resources\views/broadcast.blade.php ENDPATH**/ ?>