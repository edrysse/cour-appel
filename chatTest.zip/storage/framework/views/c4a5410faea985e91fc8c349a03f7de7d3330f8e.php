<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>نافذة الحق</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="icon" href="/img/icon.ico">
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>
    
<form action="<?php echo e(route('step4')); ?>" enctype="multipart/form-data" method="post">
    <?php echo csrf_field(); ?>
    <div class="landing-sectionHeadO">
      
            <div class="head-one"><a href="/"><img src="/img/project_nameLight.png" alt=""></a></div>
            <div class="head-twoO"><span style="color: #ffbc2b">مَحكَمة الإسْتئنَاف </span>في خدمة المواطن</div>
            <div class="head-three"><img src="/img/newLight.png" alt=""></div>
    </div>
    
    <div class="stepOne-sectionUpload">
        <div class="allSteps">
    
                <div class="allStepsOne">
                    <div class="allStepsOneOne">استلام الوصل</div>
                    <div class="allStepsOneTwo">5</div>
                    <div class="allStepsOneThree">استلام الوصل</div>
                </div>
                <div class="stepsSeparator">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
                <div class="allStepsOne">
                    <div class="allStepsOneOne">مراجعة البيانات</div>
                    <div class="allStepsOneTwo">4</div>
                    <div class="allStepsOneThree">تأكيد بيانات الطلب</div>
                </div>
                <div class="stepsSeparatorColor" style="cursor: pointer">
                    <div></div>
                </div>
                <div class="allStepsOne" style="cursor: pointer">
                    <div class="allStepsOneOne">المرفقات</div>
                    <div class="allStepsOneTwoColor">3</div>
                    <div class="allStepsOneThree">المرفقات الخاصة بالطلب</div>
                </div>
                <div class="stepsSeparatorColor" style="cursor: pointer">
                    <div></div>
                </div>
                <div class="allStepsOne" style="cursor: pointer">
                    <div class="allStepsOneOne">ملف القضية</div>
                    <div class="allStepsOneTwoColor">2</div>
                    <div class="allStepsOneThree">معلومات حول القضية</div>
                </div>
                <div class="stepsSeparatorColor" style="cursor: pointer">
                    <div></div>
                </div>
                <div class="allStepsOne" style="cursor: pointer">
                    <div class="allStepsOneOne">معلومات</div>
                    <div class="allStepsOneTwoColor">1</div>
                    <div class="allStepsOneThree">مقدم الطلب/المعني بالطلب</div>
                </div>
        </div>
        <div class="stepsIntroduction">
                <div class="stepsIntroductionOne"><img src="https://egrace.justice.gov.ma/assets/images/etapes/group_mizan.svg" alt=""></div>
                <div class="stepsIntroductionTwo">
                    <div class="stepsIntroductionTwoOne"><div style="font-weight: 700;font-size: 14px">تعريف بالمرحلة</div>
                    <div class="stepsIntroductionTwoOneNum">3</div></div>
    
                    <div class="stepsIntroductionTwoTwo">تمكنكم هذه المرحلة من إدخال معلومات حول</div>
    
                    <div class="stepsIntroductionTwoThree">
                        <div class="about">المرفقات</div>
                        <div class="about"></div>
                    </div>
                </div>
    
                <div class="stepsIntroductionThree"></div>
                
        </div>
    <div class="stepThreeInfos">
            <input type="hidden" name="selectedType" value="<?php echo e($requestData["selectedType"]); ?>" id="">
            <input type="hidden" name="selectedNacio" value="<?php echo e($requestData["selectedNacio"]); ?>" id="">
            <input type="hidden" name="selectedDocument" value="<?php echo e($requestData["selectedDocument"]); ?>" id="">
            <input type="hidden" name="chikayaGender" value="<?php echo e($requestData["chikayaGender"]); ?>" id="">
            <input type="hidden" name="lastName" value="<?php echo e($requestData["lastName"]); ?>" id="">
            <input type="hidden" name="firstName" value="<?php echo e($requestData["firstName"]); ?>" id="">
            <input type="hidden" name="documentNum" value="<?php echo e($requestData["documentNum"]); ?>" id="">
            <input type="hidden" name="email" value="<?php echo e($requestData["email"]); ?>" id="">
            <input type="hidden" name="telephone" value="<?php echo e($requestData["telephone"]); ?>" id="">
            <input type="hidden" name="dateNaissance" value="<?php echo e($requestData["dateNaissance"]); ?>" id="">
            <input type="hidden" name="crimenalGender" id="" value="<?php echo e($requestData["crimenalGender"]); ?>">
            <input type="hidden" name="lastNamec" id="" value="<?php echo e($requestData["lastNamec"]); ?>">
            <input type="hidden" name="sujet" id="" value="<?php echo e($requestData["sujet"]); ?>">
            <input type="hidden" name="firstNamec" id="" value="<?php echo e($requestData["firstNamec"]); ?>">
            <input type="hidden" name="date" id="" value="<?php echo e($requestData["date"]); ?>">
            <input type="hidden" name="time" id="" value="<?php echo e($requestData["time"]); ?>">
            
            <div class="stepThreeInfosOne">
                <input type="text" name="" id="imagePath">
                <div class="stepThreeInfosOneOne">
                    <input type="file" name="carteNacional" id="imageInput" required>
                </div>

                <script>
                    document.getElementById('imageInput').addEventListener('change', function() {
                      const file = this.files[0];
                      
                      if (file) {
                        const path = URL.createObjectURL(file);
                        
                        document.getElementById('imagePath').value = path;
                      } else {
                        document.getElementById('imagePath').value = '';
                      }
                    });
                    </script>
    
                <div class="stepThreeInfosOneTwo">
                    <label for="">(الواجهة الأمامية) صورة البطاقة الوطنية</label>
                </div>
    
    
                <div class="stepThreeInfosOneThree"><i class='bx bx-cloud-upload' style='color:#003566'  ></i></div>
            </div>
    
    
    
            <div class="stepThreeInfosOne">
                <div class="stepThreeInfosOneOne">
                    <input type="file" name="additionalImages" id="carteNacio" required>
                </div>
                <div class="stepThreeInfosOneTwo">
                    <label for="">(الواجهة الخلفية) صورة البطاقة الوطنية</label>
                </div>
    
    
                <div class="stepThreeInfosOneThree"><i class='bx bx-cloud-upload' style='color:#003566'  ></i></div>
            </div>
    
            <div class="stepInfosTheLastOne">
                <div class="stepInfosTheLastOneOne"><button type="submit"><i class='bx bx-chevron-left'></i>متابعة</button></div>
            </div>
    </div>
    </div>
</form>


<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.title = document.title + ' - ' + 'ملئ طلب شكاية الخطوة 3';
    });
</script>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.foo_ter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('foo_ter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</body>
</html>



<?php /**PATH C:\chatApp\chatTest\resources\views/complain-stepThree.blade.php ENDPATH**/ ?>