<?php
    $notices = App\Models\Notice::get();
?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>نافذة الحق</title>
    <link rel="icon" href="/img/icon.ico">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.lordicon.com/lordicon.js"></script>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<body>
    <?php if(session()->has('successAccept')): ?>
        <script>
            Swal.fire({
                position: "center-center",
                icon: "success",
                title: "<?php echo e(session('successAccept')); ?>",
                showConfirmButton: false,
                timer: 2000
            });
        </script>
    <?php endif; ?>
    <?php if(session()->has('successReject')): ?>
        <script>
            Swal.fire({
                position: "center-center",
                icon: "info",
                title: "<?php echo e(session('successReject')); ?>",
                showConfirmButton: false,
                timer: 2000
            });
        </script>
    <?php endif; ?>
    <div class="listMessages-section">
        
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-section_head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-section_head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin_navbar','data' => ['count' => count($waitingEmploye)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin_navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(count($waitingEmploye))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        
          <div class="searchResultWaiting">
            <p>تمكنكم هذه الواجهة من الإطلاع على  طلبات جهاز الحاسوب و الطابعات الخاصة بالموظفين<br><span>.واجهة خاصة بالموظفين تحت مسمى وظيفي رئيس</span></p>
          </div>


          <div class="theResult">
            
            <span class="suivie">لائحةلطلبات جهاز الحاسوب و الطابعات</span>
          </div>

        <div class="tableDiv">
            <table border="1" class="messages-table">
                <tr>
                    <th>طباعة</th>
                    <th>قبول الطلب</th>
                    <th>رفض الطلب</th>
                    <th>دواعي الإستعمال</th>
                    <th>الكمية المطلوبة</th>
                    <th>نوعية المطلوبات</th>
                    <th>الرقم الترتيبي</th>
                </tr>
                <?php $__currentLoopData = $devicesDemandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="messageRow">
                    <td>
                        <form action="<?php echo e(route('download.pdf.device')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="employe_name" value="<?php echo e($dev->employe_name); ?>">
                            <input type="hidden" name="id" value="<?php echo e($dev->id); ?>">
                            <input type="hidden" name="typeF" value="<?php echo e($dev->type_device); ?>">
                            <input type="hidden" name="nF" value="<?php echo e($dev->number_device); ?>">
                            <input type="hidden" name="why" value="<?php echo e($dev->why); ?>">
                            <input type="hidden" name="date" value="<?php echo e($dev->created_at); ?>">
                            <button type="submit" class="press">طبع</button>
                        </form>
                    </td>

                    <?php if($dev->status === 'under review'): ?>
                            <td>
                                <form action="<?php echo e(route('admin-accept-device', $dev->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="acceptDemande">✓</button>
                                </form>
                            </td>
                        <?php else: ?>
                            <?php if($dev->status === 'not approved'): ?>
                                <td><span style="color: #f03738">تم الرفض</span></td>
                            <?php else: ?>
                                <td><span style="color: #088772">تمت الموافقة</span></td>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if($dev->status === 'under review'): ?>
                            <td>
                                <form action="<?php echo e(route('admin-reject-device', $dev->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="cancelDemande"><i class='bx bx-x'></i></button>
                                </form>
                            </td>
                        <?php else: ?>
                        <td></td>
                        <?php endif; ?>
                        <td><?php echo e($dev->why); ?></td>
                        <td><?php echo e($dev->number_device); ?></td>
                        <td><?php echo e($dev->type_device); ?></td>
                        <td><?php echo e($dev->id); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.title = 'نافذة الحق' + ' - ' + 'طلبات جهاز الحاسوب و الطابعات';
        });
      </script>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.foo_ter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('foo_ter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    
    
</body>
</html><?php /**PATH C:\chatApp\chatTest\resources\views/deviceList.blade.php ENDPATH**/ ?>